class DirectionEnum:
    DOWN = 0 
    DOWN_RIGHT = 1
    RIGHT = 2
    TOP_RIGHT = 3
    UP = 4
    TOP_LEFT = 5
    LEFT = 6 
    DOWN_LEFT = 7